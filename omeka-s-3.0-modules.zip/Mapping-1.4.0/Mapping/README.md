# Mapping

Mapping is a module for Omeka S which allows you to geolocate Omeka S items and add interactive maps to Site Pages.

See the [Omeka S user manual](http://omeka.org/s/docs/user-manual/modules/mapping/) for user documentation.

## Installation

See general end user documentation for [Installing a module](http://omeka.org/s/docs/user-manual/install/)
