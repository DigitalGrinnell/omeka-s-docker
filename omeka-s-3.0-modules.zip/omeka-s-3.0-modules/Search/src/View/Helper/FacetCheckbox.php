<?php declare(strict_types=1);
namespace Search\View\Helper;

class FacetCheckbox extends AbstractFacetElement
{
    protected $partial = 'search/facet-checkbox';
}
