DROP TABLE IF EXISTS `search_page`;
DROP TABLE IF EXISTS `search_index`;
