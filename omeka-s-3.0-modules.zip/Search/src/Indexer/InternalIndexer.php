<?php declare(strict_types=1);

namespace Search\Indexer;

class InternalIndexer extends NoopIndexer
{
}
