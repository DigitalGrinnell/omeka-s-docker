<?php

namespace Search\Indexer;

class InternalIndexer extends NoopIndexer
{
}
