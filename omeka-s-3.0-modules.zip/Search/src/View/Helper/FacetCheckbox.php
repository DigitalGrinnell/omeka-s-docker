<?php
namespace Search\View\Helper;

class FacetCheckbox extends AbstractFacetElement
{
    protected $partial = 'search/facet-checkbox';
}
