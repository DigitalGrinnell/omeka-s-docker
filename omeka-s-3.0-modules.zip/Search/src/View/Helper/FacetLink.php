<?php
namespace Search\View\Helper;

class FacetLink extends AbstractFacetElement
{
    protected $partial = 'search/facet-link';
}
