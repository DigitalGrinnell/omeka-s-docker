<?php declare(strict_types=1);
namespace Search\View\Helper;

class FacetLink extends AbstractFacetElement
{
    protected $partial = 'search/facet-link';
}
